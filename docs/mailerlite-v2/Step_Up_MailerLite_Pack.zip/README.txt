Extract the ZIP, then open START-HERE.html in a browser.
Open an email with a text editor (Windows: Open with > Notepad; macOS: a plain-text editor) to copy the complete HTML into MailerLite.
Do not copy the rendered browser text into the HTML editor.
Read SETUP-GUIDE.html before activation.
The postal-address marker must be replaced in every sending file. Result and access fields must be created and populated.
The prospect and customer versions are alternatives, not two emails to send together.
Illustrations are editable SVG files with email-native equivalents already built into the HTML. The gallery can export optional PNGs for MailerLite's File manager.
No workflow is activated and no email has been sent by this pack.
